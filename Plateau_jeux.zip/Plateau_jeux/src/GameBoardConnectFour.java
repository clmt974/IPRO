import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("023a9b01-deab-4d77-9b42-fffcc9714167")
public class GameBoardConnectFour extends GameBoard {
}
