import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0428e682-bda6-49d1-92a8-bec22e762769")
public class BoardGames {
    @objid ("0492d90c-f96b-4755-89d1-c8bd6ce7fa3a")
    public Choice choice;

    @objid ("aea6a12a-76eb-48bc-b33b-e1a2091aaa64")
    public GameBoard board;

    @objid ("135dd5f0-d0b2-4387-a021-4af9f22985ba")
    public Menu menu;

    @objid ("24ea2dcd-06d4-481f-86b1-ad69818869f8")
    public void Main() {
    }

}
