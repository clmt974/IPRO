import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0428e682-bda6-49d1-92a8-bec22e762769")
public class BoardGames {
    @objid ("aea6a12a-76eb-48bc-b33b-e1a2091aaa64")
    public GameBoard board;

    @objid ("135dd5f0-d0b2-4387-a021-4af9f22985ba")
    public Menu menu;

}
