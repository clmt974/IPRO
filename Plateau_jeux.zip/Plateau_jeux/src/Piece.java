import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("39c218b7-bd32-4634-8776-31a422cf0806")
public class Piece {
    @objid ("ddff4251-39dc-4f95-8289-eabe5f7d5e27")
    private String color;

    @objid ("4f1bc589-ebc9-45b0-818a-93575235f875")
    public Piece(String couleur) {
    }

    @objid ("412550fb-a12a-43ff-84bd-e517a87d8222")
    public String getColor() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.color;
    }

    @objid ("23d9eadc-bc91-4b7c-b363-2552acf276b9")
    public void setColor(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.color = value;
    }

}
