import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5afb8c91-740d-48f2-a68d-d359b37f3ce8")
public enum Status {
    EMPTY,
    PLAYER_ONE,
    PLAYER_TWO;
}
