import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e8bc5e54-2cf0-4828-94ba-a0896289ef68")
public class Square {
    @objid ("ae042617-f34d-46d8-b268-ab3da4c59c73")
    public Piece piece;

    @objid ("5ce387bf-68f9-4a3d-a151-d020cce22cbf")
    public Status status;

    @objid ("f23132be-c303-4549-9ed4-7ecbf71db797")
    public Square() {
    }

    @objid ("d0ab292f-b9bf-4fdf-8058-08aa21dd7aa6")
    Status getStatus() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.status;
    }

    @objid ("3f4639bf-96be-412a-a80f-99e00d739877")
    void setStatus(Status value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.status = value;
    }

    @objid ("3ff5de55-92aa-4fe9-9c58-d9e4e39df903")
    Piece getPiece() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.piece;
    }

    @objid ("71e219a1-557b-4a16-ac3f-fc2485028573")
    void setPiece(Piece value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.piece = value;
    }

}
