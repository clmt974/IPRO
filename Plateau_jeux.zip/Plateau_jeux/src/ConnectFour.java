import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("023a9b01-deab-4d77-9b42-fffcc9714167")
public class ConnectFour extends GameBoard {
    @objid ("e9ff64c9-88db-4e70-bad2-83047afd9a85")
    public boolean isFull(int col) {
    }

    @objid ("ae75e23d-2e0d-4fc5-bcc0-25f12640a842")
    public ConnectFour() {
    }

}
