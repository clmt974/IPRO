import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("60a4da9a-9423-433c-86f5-cb71ef0b5248")
public enum Choice {
    EXIT,
    CONNECT_FOUR,
    FIVE_OR_MORE,
    REVERSI;
}
