import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b7098db2-f788-4ae4-8b1c-8c0ef97bdda0")
public class GameBoardReversi extends GameBoard {
}
