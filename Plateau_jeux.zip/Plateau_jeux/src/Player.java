import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b85dbd86-2f4d-40a4-8861-68cdabbb55a3")
public class Player {
    @objid ("78cbd6e6-0a1e-4cd4-bd84-df686ab2471b")
    private String name;

    @objid ("1cc43b2c-4f5b-4368-a311-172b9f3731b8")
    public String getName() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.name;
    }

    @objid ("6f126071-148c-4cd3-93dc-66e8bf127238")
    public void setName(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.name = value;
    }

    @objid ("98550967-4452-4554-adfd-0a0f4343915a")
    public Player(String n) {
    }

}
