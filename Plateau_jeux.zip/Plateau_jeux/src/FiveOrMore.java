import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("25bb7e2d-0998-4722-bce6-6bf9d0c6aed6")
public class FiveOrMore extends GameBoard {
}
