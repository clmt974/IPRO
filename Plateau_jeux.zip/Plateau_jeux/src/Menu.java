import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("28e3bcf6-3fa1-4b5c-b2b2-78f90cfa98e7")
public class Menu {
    @objid ("306d6015-662d-4da7-829b-87ca8a52c3af")
    public String[] playersName = new String[2];

    @objid ("83798527-6abe-4d06-8a7b-d2275d7602df")
    public Choice choice;

    @objid ("0c83f372-7a6c-419e-9a3b-acc7b1e493c2")
    public void printMenu() {
    }

    @objid ("c4c80fa2-320c-4bb1-bf2f-13c35197b202")
    String[] getPlayersName() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.playersName;
    }

    @objid ("b9b66675-6884-41c7-a9ce-d13ba8508574")
    void setPlayersName(String[] value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.playersName = value;
    }

    @objid ("1995b1f0-0cc3-4915-8204-4f1d6de4a244")
    void setChoice(Choice value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.choice = value;
    }

}
