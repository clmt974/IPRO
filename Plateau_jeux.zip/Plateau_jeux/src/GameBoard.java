import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("540bf929-5e36-4a70-9b22-542f5cb928b1")
public abstract class GameBoard {
    @objid ("83232e17-f782-4158-9af7-c97b4939cda8")
    public static final int WIDTH;

    @objid ("6cec96d6-3b7e-43e1-a8e2-ad0beae75775")
    public static final int HEIGHT;

    @objid ("189e481c-4939-4bdc-88c5-2174c7101831")
    public static final int FIRST_COL;

    @objid ("140943a2-ba2a-4a1a-b2be-2380302e336c")
    public static final int LAST_COL;

    @objid ("8550124b-e659-4d76-b72a-d46512da248f")
    public static final int FIRST_LINE;

    @objid ("cbbe6f1f-bb68-4905-8186-aa96dd1e8249")
    public static final int LAST_LINE;

    @objid ("e7464ebb-31d3-4e5e-85db-221d908cf925")
    public Square[] grid;

    @objid ("875d9ae7-aa67-4b16-baa2-5f10b748f8ab")
    private Player[] players = new Player[2];

    @objid ("de9399c6-41ea-42bb-9ff1-2b5025c2bbbf")
    private Player currentPlayer;

    @objid ("b486a252-5763-486a-9380-c750278b9eda")
    public boolean isFull() {
    }

    @objid ("1dd04fa1-aac9-4adb-88a1-142296c6b2ab")
    public void printBoard() {
    }

    @objid ("1dd8a4b7-2777-42d1-90df-c92d8c2f7566")
    public void nextPlayer() {
    }

    @objid ("06705421-e453-4295-9441-45d95b69d1da")
    public Player startGame() {
    }

    @objid ("cb9528cd-f30b-4120-b086-67f56e3b0717")
    public boolean hasWinner() {
    }

    @objid ("c7c88629-80fe-47df-88b8-601206f78a6c")
    public GameBoard(Player p1, Player p2) {
    }

    @objid ("f0b3d8d0-9145-4344-b5f5-5676fd63eda2")
    public void InitBoard() {
    }

    @objid ("0a2790e3-4028-48ab-9766-42c5251c7350")
    Player getCurrentPlayer() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.currentPlayer;
    }

    @objid ("4c52f19b-2bea-4d9d-8673-aa6553a0c675")
    void setCurrentPlayer(Player value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.currentPlayer = value;
    }

    @objid ("a0765009-ebce-420d-b6dd-03089362188c")
    Player[] getPlayers() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.players;
    }

    @objid ("ffbdcb9a-a639-4e08-9650-b4a75df396ca")
    void setPlayers(Player[] value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.players = value;
    }

}
