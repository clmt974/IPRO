import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("540bf929-5e36-4a70-9b22-542f5cb928b1")
public abstract class GameBoard {
    @objid ("83232e17-f782-4158-9af7-c97b4939cda8")
    public static final int WIDTH;

    @objid ("6cec96d6-3b7e-43e1-a8e2-ad0beae75775")
    public static final int HEIGHT;

    @objid ("189e481c-4939-4bdc-88c5-2174c7101831")
    public static final int FIRST_COL;

    @objid ("140943a2-ba2a-4a1a-b2be-2380302e336c")
    public static final int LAST_COL;

    @objid ("8550124b-e659-4d76-b72a-d46512da248f")
    public static final int FIRST_LINE;

    @objid ("cbbe6f1f-bb68-4905-8186-aa96dd1e8249")
    public static final int LAST_LINE;

    @objid ("116705bd-6579-40ea-b8fe-0e95f41b7977")
    public Player actualPlayer;

    @objid ("e7464ebb-31d3-4e5e-85db-221d908cf925")
    public Square[] grid;

    @objid ("875d9ae7-aa67-4b16-baa2-5f10b748f8ab")
    public Player[] players = new Player[2];

    @objid ("b486a252-5763-486a-9380-c750278b9eda")
    public boolean isFull() {
    }

    @objid ("1dd04fa1-aac9-4adb-88a1-142296c6b2ab")
    public void print() {
    }

    @objid ("1dd8a4b7-2777-42d1-90df-c92d8c2f7566")
    public void nextPlayer() {
    }

    @objid ("06705421-e453-4295-9441-45d95b69d1da")
    public void startGame() {
    }

    @objid ("e9ff64c9-88db-4e70-bad2-83047afd9a85")
    public boolean isFull(int col) {
    }

    @objid ("cb9528cd-f30b-4120-b086-67f56e3b0717")
    public boolean hasWinner() {
    }

    @objid ("c7c88629-80fe-47df-88b8-601206f78a6c")
    public GameBoard(Player p1, Player p2) {
    }

}
